USE meta_ads_spend;
SHOW TABLES;
SELECT COUNT(*) FROM raw_advertisers;
SELECT COUNT(*) FROM raw_locations;
SELECT * FROM raw_advertisers LIMIT 5;
SELECT * FROM raw_locations  LIMIT 5;

select *
from raw_advertisers LIMIT 10;

select *
from raw_locations limit 10;

describe raw_advertisers;
describe raw_locations;


DROP TABLE IF EXISTS adverstiers_clean;
create table advertisers_clean
(id int auto_increment primary key,
page_id varchar(64),
advertisers_name varchar(255),
amount_spent decimal(12,2),
total_ads int); 

SELECT
  TRIM(page_id) AS page_id,
  TRIM(page_name) AS advertiser_name,
  CAST(NULLIF(REPLACE(REPLACE(amount_spent_usd,'$',''),',',''), '') AS DECIMAL(12,2)) AS amount_spent,
  COALESCE(num_ads, 0) AS total_ads
FROM raw_advertisers;

SELECT 'raw_advertisers' AS table_name, COUNT(*) AS row_count
FROM raw_advertisers
UNION ALL
SELECT 'raw_locations' AS table_name, COUNT(*) AS row_count
FROM raw_locations;

select *
from raw_advertisers;

SELECT amount_spent_usd,
REPLACE(REPLACE(amount_spent_usd, '$', ''), ',', '') AS stripped,
    CASE 
        WHEN REPLACE(REPLACE(amount_spent_usd, '$', ''), ',', '') REGEXP '^[0-9]+(\\.[0-9]+)?$'
        THEN CAST(REPLACE(REPLACE(amount_spent_usd, '$', ''), ',', '') AS DECIMAL(12,2))
        ELSE NULL
    END AS spend_usd_clean
FROM raw_advertisers
LIMIT 50;

select
sum(page_id is null or page_id ='')as null_page_id,
sum(page_name is null or page_name='') as null_page_name,
sum(amount_spent_usd is null or amount_spent_usd='') as null_spend_text,
sum(num_ads is null or num_ads='')
from raw_advertisers;

select
sum(region_name is null or region_name='') as null_region_name,
sum(amount_spent_usd is null or amount_spent_usd='') as null_spend_text
from raw_locations;

select
count(*) as row_total,
count(DISTINCT page_id) as distinct_pages,
count(distinct page_name) as distinct_advertisers
from raw_advertisers;

select
count(*) as row_total,
count(distinct region_name) as distinct_regions
from raw_locations;

select page_id, count(*) as occurrences
from raw_advertisers
group by page_id
having count(*)>1
order by occurrences DESC
limit 30;

CREATE TABLE advertisers_deduplicated AS
SELECT ra.*
FROM raw_advertisers ra
JOIN (
    SELECT page_id, 
	MAX(CAST(REPLACE(REPLACE(amount_spent_usd,'$',''),',','') AS DECIMAL(12,2))) AS max_spend
    FROM raw_advertisers
    WHERE REPLACE(REPLACE(amount_spent_usd,'$',''),',','') REGEXP '^[0-9]+(\.[0-9]+)?$'
    GROUP BY page_id
) t
ON ra.page_id = t.page_id
   AND (
     REPLACE(REPLACE(ra.amount_spent_usd,'$',''),',','') REGEXP '^[0-9]+(\.[0-9]+)?$'
     AND CAST(REPLACE(REPLACE(ra.amount_spent_usd,'$',''),',','') AS DECIMAL(12,2)) = t.max_spend
   );
   

-- 1) how many rows and how many distinct page_ids are there now?
select count(*) as rows_total,
count(distinct page_id) as distinct_page_ids
from advertisers_deduplicated; 

select page_id,count(*) as occurrences
from advertisers_deduplicated
group by page_id
having count(*)>1;

select *
from advertisers_deduplicated 
where page_id=152601591731;

delete from advertisers_deduplicated
where page_id=152601591731
limit 1;

-- 2) Any remaining duplicated (ties at max_spend)?
select page_id, count(*) as c
from advertisers_deduplicated 
group by page_id
having c >1
limit 30;

-- 3) Do we still have unknown IDs like '0'?
select count(*) as unknown_ids
from advertisers_deduplicated
where page_id=0;

select *
from advertisers_deduplicated
where page_id=0;

delete from advertisers_deduplicated
where page_id=0
limit 1;

alter table advertisers_deduplicated 
add column id int auto_increment primary key;

drop table if exists advertisers_clean;
CREATE TABLE advertisers_clean AS
SELECT
  page_id,
  TRIM(page_name) AS advertisers_name,
  CAST(NULLIF(REPLACE(REPLACE(amount_spent_usd, '$', ''), ',', ''), '') AS DECIMAL(12,2)) AS spend_usd,
  CAST(NULLIF(REPLACE(REPLACE(amount_spent_usd, '$', ''), ',', ''), '') AS DECIMAL(12,2)) / NULLIF(num_ads, 0) AS spend_per_ad
FROM advertisers_deduplicated;

SELECT count(*) row_num, sum(spend_usd is null) null_spend
FROM advertisers_clean;

select * 
from advertisers_clean
limit 11;

alter table advertisers_clean
modify spend_usd INT;

alter table advertisers_clean
modify spend_per_ad INT;

create index idx_advertisers_page on advertisers_clean(page_id);

drop table if exists locations_clean;
create table locations_clean as
select
  UPPER(TRIM(region_name)) as region,
  amount_spent_usd
from raw_locations
where region_name is not null
and region_name <> '';

select *
from locations_clean;

describe raw_advertisers;
describe advertisers_clean;

-- top 25 advertisers by spend and top 10 shares
with ra_dedup as
(select page_id,
max(Cast(replace(num_ads,',','') as unsigned)) as num_ads 
from raw_advertisers
group by page_id),
-- [ABOVE QUERY] 1 row per page_id from raw advertisers and then parse and pick a dingle value 
ac_agg as
(select page_id, advertisers_name, 
sum(spend_usd) as spend_usd
from advertisers_clean
group by page_id, advertisers_name)
-- [ABOVE] 1 row per page_id from advertisers_clean
select ac_agg.advertisers_name, 
sum(ac_agg.spend_usd) as total_spend_usd,
sum(coalesce(ra_dedup.num_ads, 0)) as number_of_ads, 
round(sum(ac_agg.spend_usd)/ nullif(sum(coalesce(ra_dedup.num_ads,0)),0),0)as avg_spend_per_ad
from ac_agg
left join ra_dedup using (page_id)
group by ac_agg.advertisers_name
order by total_spend_usd desc
limit 25;

-- total 10 share of total spend(%)
select round(100 *(select sum(total_spend_usd)
from (select advertisers_name, sum(spend_usd) as total_spend_usd
from advertisers_clean
group by advertisers_name
order by total_spend_usd desc
limit 10) as top10) 
/
(select sum(total_spend_usd)
from (select advertisers_name, sum(spend_usd) as total_spend_usd
from advertisers_clean
group by advertisers_name) as all_adv), 2) as top10_share_pct;

select advertisers_name, round(sum(spend_usd)/1000000,2) as total_spend_millions,
round(100 * sum(spend_usd) / (select sum(spend_usd) from advertisers_clean),2) as spend_share_pct
from advertisers_clean
group by advertisers_name
order by sum(spend_usd) desc
limit 10;

-- Spend by page (clean types)
create or replace view v_advertisers_clean as
select page_id,
trim(advertisers_name) as advertisers_name,
cast(spend_usd as unsigned) as spend_usd
from advertisers_clean
where advertisers_name is not null and advertisers_name <> '';

-- 1. Ad Saturation Index (ASR)
USE meta_ads_spend;

-- 2) Sanity checks
SHOW TABLES LIKE 'advertisers_clean';
SHOW TABLES LIKE 'raw_advertisers';

-- 3) Recreate the view inside THIS schema (force drop, fully-qualify sources)
DROP VIEW IF EXISTS meta_ads_spend.v_advertisers_clean;

CREATE VIEW meta_ads_spend.v_advertisers_clean AS
SELECT 
    ac.page_id,
    TRIM(ac.advertisers_name) AS advertisers_name,
    CAST(ac.spend_usd AS UNSIGNED) AS spend_usd
FROM meta_ads_spend.advertisers_clean AS ac
WHERE ac.advertisers_name IS NOT NULL
  AND ac.advertisers_name <> '';

-- 4) Verify the view is present and has rows
SHOW FULL TABLES IN meta_ads_spend WHERE Table_type = 'VIEW';
SELECT COUNT(*) AS rows_in_view FROM meta_ads_spend.v_advertisers_clean;

-- 5) Ad Saturation Index (schema-qualified + safe casting)
select v.advertisers_name,
sum(v.spend_usd) as total_spend_usd, 
sum(coalesce(cast(replace(r.num_ads,',','') as unsigned),0)) as total_ads,
round(
	100.0 * sum(coalesce(cast(replace(r.num_ads,',','') as unsigned),0))
    /
nullif(
(select sum(coalesce(cast(replace(num_ads,',','') as unsigned),0)) 
from meta_ads_spend.raw_advertisers),0),2) as ad_saturation_pct
from meta_ads_spend.v_advertisers_clean as v
left join meta_ads_spend.raw_advertisers as r 
using (page_id)
group by v.advertisers_name
having total_ads > 0
order by ad_saturation_pct desc
limit 15;

-- dedup the data
USE meta_ads_spend;

SELECT 
    v.advertisers_name,
    SUM(v.spend_usd) AS total_spend_usd,
    SUM(COALESCE(a.num_ads,0)) AS total_ads,
    ROUND(100.0 * SUM(COALESCE(a.num_ads,0)) / MAX(t.total_ads_all), 2) AS ad_saturation_pct
FROM meta_ads_spend.v_advertisers_clean AS v
LEFT JOIN (
    -- Deduplicate: one ad count per page_id
    SELECT page_id,
           MAX(CAST(REPLACE(num_ads, ',', '') AS UNSIGNED)) AS num_ads
    FROM meta_ads_spend.raw_advertisers
    GROUP BY page_id
) AS a USING (page_id)
CROSS JOIN (
    -- Constant denominator for the whole query
    SELECT SUM(num_ads) AS total_ads_all
    FROM (
        SELECT MAX(CAST(REPLACE(num_ads, ',', '') AS UNSIGNED)) AS num_ads
        FROM meta_ads_spend.raw_advertisers
        GROUP BY page_id
    ) z
) AS t
GROUP BY v.advertisers_name
HAVING total_ads > 0
ORDER BY ad_saturation_pct DESC
LIMIT 15;

-- Total ads across the platform (after per-page dedupe)
select sum(num_ads) as total_ads_all_check
from (
	select max(cast(replace(num_ads,',','') as unsigned)) as num_ads
    from meta_ads_spend.raw_advertisers
    group by page_id
    ) x;

-- Sum of % for the current TOP 15 
SELECT ROUND(SUM(ad_saturation_pct), 2) AS sum_top15_pct
FROM (
  SELECT 
      v.advertisers_name,
      SUM(v.spend_usd) AS total_spend_usd,
      SUM(COALESCE(a.num_ads,0)) AS total_ads,
      ROUND(100.0 * SUM(COALESCE(a.num_ads,0)) / MAX(t.total_ads_all), 2) AS ad_saturation_pct
  FROM meta_ads_spend.v_advertisers_clean AS v
  LEFT JOIN (
      SELECT page_id,
             MAX(CAST(REPLACE(num_ads, ',', '') AS UNSIGNED)) AS num_ads
      FROM meta_ads_spend.raw_advertisers
      GROUP BY page_id
  ) AS a USING (page_id)
  CROSS JOIN (
      SELECT SUM(num_ads) AS total_ads_all
      FROM (
          SELECT MAX(CAST(REPLACE(num_ads, ',', '') AS UNSIGNED)) AS num_ads
          FROM meta_ads_spend.raw_advertisers
          GROUP BY page_id
      ) z
  ) AS t
  GROUP BY v.advertisers_name
  HAVING total_ads > 0
  ORDER BY ad_saturation_pct DESC
  LIMIT 15
) q;

-- Spend–Volume Correlation (Marketing Efficiency Relationship)
SELECT 
  ROUND(
    (
      SUM((t.total_spend_usd - avg_x.avg_spend) * (t.total_ads - avg_y.avg_ads))
    ) /
    SQRT(
      SUM(POW(t.total_spend_usd - avg_x.avg_spend, 2)) *
      SUM(POW(t.total_ads - avg_y.avg_ads, 2))
    )
  ,3) AS spend_volume_corr
FROM (
  -- per advertiser totals
  SELECT 
    v.advertisers_name,
    SUM(v.spend_usd) AS total_spend_usd,
    SUM(COALESCE(a.num_ads,0)) AS total_ads
  FROM meta_ads_spend.v_advertisers_clean AS v
  LEFT JOIN (
      SELECT page_id,
             MAX(CAST(REPLACE(num_ads, ',', '') AS UNSIGNED)) AS num_ads
      FROM meta_ads_spend.raw_advertisers
      GROUP BY page_id
  ) AS a USING (page_id)
  GROUP BY v.advertisers_name
  HAVING total_ads > 0
) AS t
CROSS JOIN (
  -- averages for correlation math
  SELECT 
    AVG(total_spend_usd) AS avg_spend,
    AVG(total_ads) AS avg_ads
  FROM (
    SELECT 
      v.advertisers_name,
      SUM(v.spend_usd) AS total_spend_usd,
      SUM(COALESCE(a.num_ads,0)) AS total_ads
    FROM meta_ads_spend.v_advertisers_clean AS v
    LEFT JOIN (
        SELECT page_id,
               MAX(CAST(REPLACE(num_ads, ',', '') AS UNSIGNED)) AS num_ads
        FROM meta_ads_spend.raw_advertisers
        GROUP BY page_id
    ) AS a USING (page_id)
    GROUP BY v.advertisers_name
    HAVING total_ads > 0
  ) x
) AS avg_x
CROSS JOIN (
  SELECT 
    AVG(total_ads) AS avg_ads
  FROM (
    SELECT 
      v.advertisers_name,
      SUM(COALESCE(a.num_ads,0)) AS total_ads
    FROM meta_ads_spend.v_advertisers_clean AS v
    LEFT JOIN (
        SELECT page_id,
               MAX(CAST(REPLACE(num_ads, ',', '') AS UNSIGNED)) AS num_ads
        FROM meta_ads_spend.raw_advertisers
        GROUP BY page_id
    ) AS a USING (page_id)
    GROUP BY v.advertisers_name
    HAVING total_ads > 0
  ) y
) AS avg_y;

-- Spend Concentration (Herfindahl Index)

-- Step 1 & 2: Computing total spend per advertiser and total spend overall
WITH advertiser_spend AS (
    SELECT 
        v.advertisers_name,
        SUM(v.spend_usd) AS total_spend_usd
    FROM meta_ads_spend.v_advertisers_clean AS v
    GROUP BY v.advertisers_name
),
total_spend AS (
    SELECT SUM(total_spend_usd) AS total_spend_all
    FROM advertiser_spend
)

-- Step 3 & 4: Computing HHI
SELECT 
    ROUND(SUM(POW(a.total_spend_usd / t.total_spend_all, 2)), 4) AS hhi_index,
    CASE 
        WHEN SUM(POW(a.total_spend_usd / t.total_spend_all, 2)) < 0.15 THEN 'Low / Competitive'
        WHEN SUM(POW(a.total_spend_usd / t.total_spend_all, 2)) < 0.25 THEN 'Moderate Concentration'
        ELSE 'High Concentration / Oligopoly'
    END AS market_structure
FROM advertiser_spend a
CROSS JOIN total_spend t;

-- ROI efficiency analysis
USE meta_ads_spend;

WITH advertiser_stats AS (
    SELECT 
        v.advertisers_name,
        SUM(v.spend_usd) AS total_spend_usd,
        SUM(COALESCE(a.num_ads,0)) AS total_ads,
        ROUND(SUM(v.spend_usd) / NULLIF(SUM(COALESCE(a.num_ads,0)),0),2) AS spend_per_ad,
        ROUND(SUM(COALESCE(a.num_ads,0)) / NULLIF(SUM(v.spend_usd)/1000,0),2) AS ads_per_1k
    FROM meta_ads_spend.v_advertisers_clean AS v
    LEFT JOIN (
        SELECT page_id,
               MAX(CAST(REPLACE(num_ads, ',', '') AS UNSIGNED)) AS num_ads
        FROM meta_ads_spend.raw_advertisers
        GROUP BY page_id
    ) a USING (page_id)
    GROUP BY v.advertisers_name
    HAVING total_ads > 0
)
SELECT 
    a.advertisers_name,
    a.total_spend_usd,
    a.total_ads,
    a.spend_per_ad,
    a.ads_per_1k,
    ROUND(a.ads_per_1k / stats.avg_ads_per_1k,2) AS efficiency_index,
    CASE 
        WHEN a.ads_per_1k / stats.avg_ads_per_1k >= 1.3 THEN 'High ROI'
        WHEN a.ads_per_1k / stats.avg_ads_per_1k BETWEEN 0.7 AND 1.3 THEN 'Average ROI'
        ELSE 'Low ROI'
    END AS roi_category
FROM advertiser_stats a
CROSS JOIN (
    SELECT AVG(ads_per_1k) AS avg_ads_per_1k FROM advertiser_stats
) stats
ORDER BY efficiency_index DESC
LIMIT 25;

USE meta_ads_spend;

WITH spend_share AS (
  SELECT 
      advertisers_name,
      SUM(spend_usd) AS total_spend_usd,
      SUM(spend_usd) / (SELECT SUM(spend_usd) FROM advertisers_clean) AS spend_share
  FROM advertisers_clean
  GROUP BY advertisers_name
)
SELECT 
    ROUND(SUM(POW(spend_share, 2)), 4) AS hhi_index,
    CASE
        WHEN SUM(POW(spend_share, 2)) < 0.15 THEN 'Low / Competitive Market'
        WHEN SUM(POW(spend_share, 2)) BETWEEN 0.15 AND 0.25 THEN 'Moderately Concentrated'
        ELSE 'Highly Concentrated / Oligopoly'
    END AS market_structure
FROM spend_share;


-- CR10
SELECT ROUND(100 * SUM(total_spend_usd) / @total, 2) AS CR10_spend_share_pct
FROM (
  SELECT SUM(spend_usd) AS total_spend_usd
  FROM advertisers_clean
  GROUP BY advertisers_name
  ORDER BY total_spend_usd DESC
  LIMIT 10
) t;


-- spend volatility index
SELECT 
  ROUND(STDDEV_SAMP(total_spend_usd) / AVG(total_spend_usd), 2) AS spend_volatility_index
FROM (
  SELECT advertisers_name, SUM(spend_usd) AS total_spend_usd
  FROM advertisers_clean
  GROUP BY advertisers_name
) t;

use meta_ads_spend; 
show tables;
describe raw_advertisers;
describe raw_locations;
describe ad_spend_locations;
describe advertisers_deduplicated;
describe locations_clean;
describe advertisers_clean;
describe v_raw_advertisers;
describe v_advertisers_clean;

SELECT
  advertisers_name,
  SUM(spend_usd) AS advertiser_spend,
  ROUND(SUM(spend_usd) / t.total_spend, 4) AS market_share,
  CASE
    WHEN (SUM(spend_usd) / t.total_spend) < 0.15 THEN 'Low / Competitive Market'
    WHEN (SUM(spend_usd) / t.total_spend) < 0.25 THEN 'Moderate Concentration'
    ELSE 'High Concentration / Oligopoly'
  END AS market_structure
FROM advertisers_clean
CROSS JOIN (
    SELECT SUM(spend_usd) AS total_spend FROM advertisers_clean
) t
GROUP BY advertisers_name, t.total_spend
ORDER BY market_share DESC
Limit 15;

select *
from locations_clean;
